# VOICE-TO-TEXT 
" Simple Program To Convert Voice To Text "

Install homebrew 
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install.sh)"
Check if homebrew is install sucessfully
  brew help
Install speech recognisition 
  pip3 install SpeechRecognisition
Install pyaudio
   pip install pyAudio
Run the program
  python filepath voice_to_text_ex.py 
Say bye to abort the program.
